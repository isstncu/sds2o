import json
import cv2
import numpy as np

from torch.utils.data import Dataset
import skimage.io as io
import tifffile as tiff

class MyDataset(Dataset):
    def __init__(self):
        self.data = []
        with open('./training/fill50k/prompt.json', 'rt') as f:
            for line in f:
                self.data.append(json.loads(line))

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        item = self.data[idx]

        source_filename = item['source']
        target_filename = item['target']
        prompt = item['prompt']

        source = cv2.imread('./training/fill50k/' + source_filename)
        target = cv2.imread('./training/fill50k/' + target_filename)

        # Do not forget that OpenCV read images in BGR order.
        source = cv2.cvtColor(source, cv2.COLOR_BGR2RGB)
        target = cv2.cvtColor(target, cv2.COLOR_BGR2RGB)

        # Normalize source images to [0, 1].
        source = source.astype(np.float32) / 255.0

        # Normalize target images to [-1, 1].
        target = (target.astype(np.float32) / 127.5) - 1.0

        return dict(jpg=target, txt=prompt, hint=source)


###################################################################################################################
import numpy as np
import random
import string
from torch.utils.data import Dataset, DataLoader
import blobfile as bf
from PIL import Image
import math

def _list_image_files_recursively(data_dir):
    results = []
    for entry in sorted(bf.listdir(data_dir)):
        full_path = bf.join(data_dir, entry)
        ext = entry.split(".")[-1]
        if "." in entry and ext.lower() in ["jpg", "jpeg", "png", "gif", "tif"]:
            results.append(full_path)
        elif bf.isdir(full_path):
            results.extend(_list_image_files_recursively(full_path))
    return results

def center_crop_arr(pil_image, image_size):
    # We are not on a new enough PIL to support the `reducing_gap`
    # argument, which uses BOX downsampling at powers of two first.
    # Thus, we do it by hand to improve downsample quality.
    while min(*pil_image.size) >= 2 * image_size:
        pil_image = pil_image.resize(
            tuple(x // 2 for x in pil_image.size), resample=Image.BOX
        )

    scale = image_size / min(*pil_image.size)
    pil_image = pil_image.resize(
        tuple(round(x * scale) for x in pil_image.size), resample=Image.BICUBIC
    )

    arr = np.array(pil_image)
    crop_y = (arr.shape[0] - image_size) // 2
    crop_x = (arr.shape[1] - image_size) // 2
    return arr[crop_y : crop_y + image_size, crop_x : crop_x + image_size]

def random_crop_arr(pil_image, image_size, min_crop_frac=0.8, max_crop_frac=1.0):
    min_smaller_dim_size = math.ceil(image_size / max_crop_frac)
    max_smaller_dim_size = math.ceil(image_size / min_crop_frac)
    smaller_dim_size = random.randrange(min_smaller_dim_size, max_smaller_dim_size + 1)

    # We are not on a new enough PIL to support the `reducing_gap`
    # argument, which uses BOX downsampling at powers of two first.
    # Thus, we do it by hand to improve downsample quality.
    while min(*pil_image.size) >= 2 * smaller_dim_size:
        pil_image = pil_image.resize(
            tuple(x // 2 for x in pil_image.size), resample=Image.BOX
        )

    scale = smaller_dim_size / min(*pil_image.size)
    pil_image = pil_image.resize(
        tuple(round(x * scale) for x in pil_image.size), resample=Image.BICUBIC
    )

    arr = np.array(pil_image)
    crop_y = random.randrange(arr.shape[0] - image_size + 1)
    crop_x = random.randrange(arr.shape[1] - image_size + 1)
    return arr[crop_y : crop_y + image_size, crop_x : crop_x + image_size]


def x0_process(x0):
    # img = (x0 * 255).astype(np.uint8)
    img = x0
    img[img == 0] = 1
    img = np.log(img) / np.log(255.0)
    return img.astype(np.float32)


def load_data(
    cond_dir,
    gt_dir,
    image_size,
    class_cond=False,
    random_crop=False,
    random_flip=False,
):
    """
    For a dataset, create a generator over (images, kwargs) pairs.

    Each images is an NCHW float tensor, and the kwargs dict contains zero or
    more keys, each of which map to a batched Tensor of their own.
    The kwargs dict can be used for class labels, in which case the key is "y"
    and the values are integer tensors of class labels.

    :param data_dir: a dataset directory.
    :param image_size: the size to which images are resized.
    :param class_cond: if True, include a "y" key in returned dicts for class
                       label. If classes are not available and this is true, an
                       exception will be raised.
    :param random_crop: if True, randomly crop the images for augmentation.
    :param random_flip: if True, randomly flip the images for augmentation.
    """
    print("cond_dir: ", cond_dir)
    print("gt_dir: ", gt_dir)
    if not cond_dir or not gt_dir:
        raise ValueError("unspecified data directory")

    all_files_sar = _list_image_files_recursively(cond_dir)
    all_files_opt = _list_image_files_recursively(gt_dir)
    classes = None
    #
    # all_files_sar.sort(key=lambda x: int(x[len(cond_dir) + 1:].split('.')[0]))
    # all_files_opt.sort(key=lambda x: int(x[len(gt_dir) + 1:].split('.')[0]))

    if class_cond:
        # Assume classes are the first part of the filename,
        # before an underscore.
        class_names = [bf.basename(path).split("_")[0] for path in gt_dir]
        sorted_classes = {x: i for i, x in enumerate(sorted(set(class_names)))}
        classes = [sorted_classes[x] for x in class_names]
    dataset = ImageDataset(
        image_size,
        all_files_sar,
        all_files_opt,
        classes=classes,
        random_crop=random_crop,
        random_flip=random_flip,
    )
    return dataset

class ImageDataset(Dataset):
    def __init__(
        self,
        resolution,
        image_paths_sar,
        image_paths_opt,
        classes=None,
        shard=0,
        num_shards=1,
        random_crop=False,
        random_flip=True,
    ):
        super().__init__()
        self.resolution = resolution
        self.local_images_sar = image_paths_sar[shard:][::num_shards]
        self.local_images_opt = image_paths_opt[shard:][::num_shards]
        self.local_classes = None if classes is None else classes[shard:][::num_shards]
        self.random_crop = random_crop
        self.random_flip = random_flip

    def __len__(self):
        return len(self.local_images_sar)

    def __getitem__(self, idx):
        path_sar = self.local_images_sar[idx]
        path_opt = self.local_images_opt[idx]
        with bf.BlobFile(path_sar, "rb") as f:
            pil_image_sar = Image.open(f)
            pil_image_sar.load()
        pil_image_sar = pil_image_sar.convert("RGB")
        with bf.BlobFile(path_opt, "rb") as f:
            pil_image_opt = Image.open(f)
            pil_image_opt.load()
        pil_image_opt = pil_image_opt.convert("RGB")

        if self.random_crop:
            arr_sar = random_crop_arr(pil_image_sar, self.resolution)
            arr_opt = random_crop_arr(pil_image_opt, self.resolution)
        else:
            arr_sar = center_crop_arr(pil_image_sar, self.resolution)
            arr_opt = center_crop_arr(pil_image_opt, self.resolution)

        if self.random_flip and random.random() < 0.5:
            arr_sar = arr_sar[:, ::-1]
            arr_opt = arr_opt[:, ::-1]

        arr_sar = arr_sar.astype(np.float32) / 127.5 - 1
        arr_opt = arr_opt.astype(np.float32) / 127.5 - 1
        out_dict = {}
        if self.local_classes is not None:
            out_dict["y"] = np.array(self.local_classes[idx], dtype=np.int64)
        return dict(image=arr_opt, txt='', hint=arr_sar)

def load_tif_data(    
    data_dir_input,
    data_dir_gt,
):
    print("data_dir_input: ", data_dir_input)
    print("data_dir_gt: ", data_dir_gt)
    if not data_dir_input or not data_dir_gt:
        raise ValueError("unspecified data directory")

    all_files_input = _list_image_files_recursively(data_dir_input)
    all_files_gt = _list_image_files_recursively(data_dir_gt)

    dataset = TifDataset(all_files_input, all_files_gt,)
    return dataset 

class TifDataset(Dataset):
    def __init__(
        self,
        all_files_input,
        all_files_gt,
        shard=0,
        num_shards=1,

    ):
        super().__init__()
        self.local_images_input = all_files_input[shard:][::num_shards]
        self.local_images_gt = all_files_gt[shard:][::num_shards]

    def __len__(self):
        return len(self.local_images_input)

    def __getitem__(self, idx):
        path_input = self.local_images_input[idx]
        path_gt = self.local_images_gt[idx]
        
        arr_input = tiff.imread(path_input) / 127.5 - 1
        arr_gt = tiff.imread(path_gt) / 127.5 - 1

        arr_input = arr_input.astype(np.float32)
        arr_gt = arr_gt.astype(np.float32)
        return dict(image=arr_gt, txt='', hint=arr_input)


import os
import random
import skimage.io as io
import pytorch_lightning as pl
from torch.utils.data import Dataset, DataLoader

def load_finetune_data(type,
                       gt_dir, 
                       cond_dir, 
                       batch_size=4, 
                       num_workers=0, 
                       val_size=0.15, 
                       size=256):
    assert type in ("train", "val", "test")
    dataModule = GRDDataModule(gt_dir, cond_dir, batch_size, num_workers, val_size, size)
    if type == "train":
        return dataModule.train_ds
    elif type == "val":
        return dataModule.val_ds
    elif type == "test":
        return dataModule.test_ds

class GRDDataset(Dataset):
    def __init__(self, gt_dir, cond_dir, cond_images, size=256):
        self.gt_dir = gt_dir
        self.cond_dir = cond_dir
        self.gt_list = os.listdir(gt_dir)
        self.cond_list = cond_images
        self.size = size
        self.pair= {
         "S1_20220719":      "S2_20220719",    
         "S1_20220907":      "S2_20220907",    
         "S1_20220921":      "S2_20220922",    
         "S1_20221019":      "S2_20221018",    
         "S1_20221028":      "S2_20221028",    
         "S1_20221031":      "S2_20221101",    
         "S1_20221103":      "S2_20221103",    
         "S1_20221104":      "S2_20221104",    
         "S1_20221112":      "S2_20221113",    
         "S1_20221125":      "S2_20221125",    
         "S1_20221129":      "S2_20221128",    
         "S1_20221218_18":   "S2_20221218_18",
         "S1_20221218_19":   "S2_20221218_19",
         "S1_20221222":      "S2_20221221",    
         "S1_20221230":      "S2_20221231",    
        }
    def __len__(self):
        return len(self.cond_list)
    def __getitem__(self, idx):
        cond_name = self.cond_list[idx]
        cond = io.imread(os.path.join(self.cond_dir, cond_name))
        gt_name = self.pair[cond_name.split("-")[0]] + "-" + cond_name.split("-")[1].replace("tif", "npy")
        gt = np.load(os.path.join(self.gt_dir, gt_name))
        return dict(image=gt, 
                    hint=self.transform(cond), 
                    txt='', 
                    gt_name=gt_name, 
                    cond_name=cond_name)
    
    def transform(self, image):
        image = image.transpose(2, 0, 1).astype("float32") / 5000 - 1
        # image = self.optimized_linear(image)
        # image = image.transpose(2, 0, 1).astype("float32") / 127.5 - 1
        return image
    
    @staticmethod
    def percent_linear(arr, percent=2):
        arr_min, arr_max = np.percentile(arr, (percent, 100-percent))
        arr = (arr - arr_min) / (arr_max - arr_min) * 255
        arr = np.clip(arr, 0, 255)
        return np.uint8(arr)
    
    @staticmethod
    def optimized_linear(arr):
        a, b = np.percentile(arr, (2.5, 99))
        c = a - 0.1 * (b - a)
        d = b + 0.5 * (b - a)
        arr = (arr - c) / (d - c) * 255
        arr = np.clip(arr, 0, 255)
        return np.uint8(arr)

class GRDDataModule():    
    def __init__(self, gt_dir, cond_dir, batch_size=4, num_workers=0, val_size=0.15, size=256):
        super().__init__()
        self.gt_dir = gt_dir
        self.cond_dir = cond_dir
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.val_size = val_size
        self.size = size
        self.setup('fit')
    def setup(self, stage):
        all_images = sorted([u for u in os.listdir(self.cond_dir)])
        random.seed(42)
        random.shuffle(all_images)
        train_size = int((1-self.val_size)*len(all_images))
        train_images = all_images[:train_size]
        val_images = all_images[train_size:]
        test_size = int(0.3*len(val_images))
        test_images = val_images[:test_size]
        val_images = val_images[test_size:]
        self.train_ds = GRDDataset(self.gt_dir, self.cond_dir, train_images, self.size)
        self.val_ds = GRDDataset(self.gt_dir, self.cond_dir, val_images, self.size)
        self.test_ds = GRDDataset(self.gt_dir, self.cond_dir, test_images, self.size)
        print(f"Train size: {len(self.train_ds)}, Val size: {len(self.val_ds)}, Test size: {len(self.test_ds)}")
        print(f"Total size: {len(self.train_ds)+len(self.val_ds)+len(self.test_ds)}")
    def train_dataloader(self):
        return DataLoader(self.train_ds, batch_size=self.batch_size, shuffle=True, num_workers=self.num_workers)

    def val_dataloader(self):
        return DataLoader(self.val_ds, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers)

    def test_dataloader(self):
        return DataLoader(self.test_ds, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers)

class SEN12Dataset(Dataset):
    def __init__(
        self,
        gt_dir,
        cond_dir,
        cond_images
    ):
        super().__init__()
        self.gt_dir = gt_dir
        self.cond_dir = cond_dir
        self.gt_list = os.listdir(gt_dir)
        self.cond_list = cond_images

    def __len__(self):
        return len(self.cond_list)

    def __getitem__(self, idx):
        cond_name = self.cond_list[idx]
        gt_name = cond_name.replace("_s1_", "_s2_")
        cond = np.array(Image.open(os.path.join(self.cond_dir, cond_name)).convert("RGB"))
        # gt = np.array(Image.open(os.path.join(self.gt_dir, gt_name)).convert("RGB"))
        gt = np.load(os.path.join(self.gt_dir, gt_name.replace("png", "npy")))

        return dict(
                    # image=self.transform(gt),
                    image=gt,
                    hint=self.transform(cond),
                    txt='',
                    gt_name=gt_name,
                    cond_name=cond_name)

    def transform(self, image):
        return image.transpose(2, 0, 1).astype("float32") / 127.5 - 1

class SEN12DataModule():    
    def __init__(self, gt_dir, cond_dir, batch_size=4, num_workers=0, val_size=0.15):
        super().__init__()
        self.gt_dir = gt_dir
        self.cond_dir = cond_dir
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.val_size = val_size
        self.setup('fit')

    def setup(self, stage):
        all_images = sorted([u for u in os.listdir(self.cond_dir)])
        random.seed(42)
        random.shuffle(all_images)
        train_size = int((1-self.val_size)*len(all_images))
        train_images = all_images[:train_size]
        val_images = all_images[train_size:]
        test_size = int(0.3*len(val_images))
        test_images = val_images[:test_size]
        val_images = val_images[test_size:]
        self.train_ds = SEN12Dataset(self.gt_dir, self.cond_dir, train_images)
        self.val_ds = SEN12Dataset(self.gt_dir, self.cond_dir, val_images)
        self.test_ds = SEN12Dataset(self.gt_dir, self.cond_dir, test_images)
        print(f"Train size: {len(self.train_ds)}, Val size: {len(self.val_ds)}, Test size: {len(self.test_ds)}")
        print(f"Total size: {len(self.train_ds)+len(self.val_ds)+len(self.test_ds)}")

    def train_dataloader(self):
        return DataLoader(self.train_ds, batch_size=self.batch_size, shuffle=True, num_workers=self.num_workers)

    def val_dataloader(self):
        return DataLoader(self.val_ds, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers)

    def test_dataloader(self):
        return DataLoader(self.test_ds, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers)
