    # --checkpoint logs/2024-06-28T14-27-56_control_sd15_ini_SEN12_URBAN/testtube/version_0/checkpoints/epoch=399-step=249999.ckpt \
CUDA_VISIBLE_DEVICES=2 \
python sample.py \
    --checkpoint logs/2024-06-28T14-27-56_control_sd15_ini_SEN12_URBAN/testtube/version_1/checkpoints/epoch=399-step=249999.ckpt \
    --test_dir data/SEN12_URBAN/test \
    --save_dir test_samples/SEN12_URBAN/0701


CUDA_VISIBLE_DEVICES=3 \
python sample.py \
    --checkpoint /home/jbwei/crli/ControlNet-v1-1-nightly/logs/2024-06-22T13-43-17_control_sd15_ini_/home/jbwei/Pke/data/synthesis/testtube/version_0/checkpoints/epoch=271-step=199999.ckpt \
    --test_dir /home/jbwei/Pke/data/synthesis/test \
    --save_dir test_samples/synthesis/step=20w

CUDA_VISIBLE_DEVICES=3 \
python sample.py \
    --checkpoint /home/jbwei/crli/ControlNet-v1-1-nightly/logs/2024-06-22T13-43-17_control_sd15_ini_/home/jbwei/Pke/data/synthesis/testtube/version_0/checkpoints/epoch=338-step=249999.ckpt \
    --test_dir /home/jbwei/Pke/data/synthesis/test \
    --save_dir test_samples/synthesis/step=25w

CUDA_VISIBLE_DEVICES=3 \
python sample.py \
    --checkpoint /home/jbwei/crli/ControlNet-v1-1-nightly/logs/2024-06-22T13-43-17_control_sd15_ini_/home/jbwei/Pke/data/synthesis/testtube/version_0/checkpoints/epoch=338-step=249999.ckpt \
    --test_dir /home/jbwei/Pke/data/synthesis/test \
    --save_dir test_samples/synthesis/step=30w

CUDA_VISIBLE_DEVICES=3 \
python sample.py \
    --checkpoint /home/jbwei/crli/ControlNet-v1-1-nightly/logs/2024-06-22T13-43-17_control_sd15_ini_/home/jbwei/Pke/data/synthesis/testtube/version_0/checkpoints/epoch=474-step=349999.ckpt \
    --test_dir /home/jbwei/Pke/data/synthesis/test \
    --save_dir test_samples/synthesis/step=35w

CUDA_VISIBLE_DEVICES=2 \
python sample.py \
    --checkpoint "/data1/jbwei/crli/ControlNet-v1-1-nightly/logs/2024-07-08T11-03-27_control_sd15_ini_/home/jbwei/Pke/data/synthesis/testtube/version_0/checkpoints/epoch=474-step=349999.ckpt" \
    --test_dir /home/jbwei/Pke/data/synthesis/test/ \
    --save_dir test_samples/synthesis/0710/step=35


CUDA_VISIBLE_DEVICES=3 \
python sample.py \
    --checkpoint logs/epoch=399-step=249999.ckpt \
    --test_dir data/SEN12_AGRI/test \
    --save_dir test_samples/SEN12_AGRI/0717
