import config
config.save_memory = False
from share import *

import os
import argparse
import cv2
import einops
import numpy as np
import torch
import random
from skimage import io

from pytorch_lightning import seed_everything
from annotator.util import resize_image, HWC3
from annotator.canny import CannyDetector
from cldm.model import create_model, load_state_dict
from cldm.ddim_hacked import DDIMSampler


def percent_linear(arr, percent=2):
    arr_min, arr_max = np.percentile(arr, (percent, 100-percent))
    arr = (arr - arr_min) / (arr_max - arr_min) * 255
    arr = np.clip(arr, 0, 255)
    return np.uint8(arr)

import os
import random
import skimage.io as io
import pytorch_lightning as pl
from torch.utils.data import Dataset, DataLoader

class FinetuneData(Dataset):
    def __init__(self, gt_dir, cond_dir, cond_images, size=256):
        self.gt_dir = gt_dir
        self.cond_dir = cond_dir
        self.gt_list = os.listdir(gt_dir)
        self.cond_list = cond_images
        self.size = size
        self.pair= {
         "S1_20220719":      "S2_20220719",    
         "S1_20220907":      "S2_20220907",    
         "S1_20220921":      "S2_20220922",    
         "S1_20221019":      "S2_20221018",    
         "S1_20221028":      "S2_20221028",    
         "S1_20221031":      "S2_20221101",    
         "S1_20221103":      "S2_20221103",    
         "S1_20221104":      "S2_20221104",    
         "S1_20221112":      "S2_20221113",    
         "S1_20221125":      "S2_20221125",    
         "S1_20221129":      "S2_20221128",    
         "S1_20221218_18":   "S2_20221218_18",
         "S1_20221218_19":   "S2_20221218_19",
         "S1_20221222":      "S2_20221221",    
         "S1_20221230":      "S2_20221231",    
        }
    def __len__(self):
        return len(self.cond_list)
    def __getitem__(self, idx):
        cond_name = self.cond_list[idx]
        cond = io.imread(os.path.join(self.cond_dir, cond_name))
        gt_name = self.pair[cond_name.split("-")[0]] + "-" + cond_name.split("-")[1]
        gt = io.imread(os.path.join(self.gt_dir, gt_name))
        gt = gt[:, :, :3][:, :, ::-1]
        return dict(image=self.transform(gt), 
                    hint=self.transform(cond), 
                    txt='',
                    gt_name=gt_name,
                    cond_name=cond_name)
    
    def transform(self, image):
        image = image.transpose(2, 0, 1).astype("float32") / 5000 - 1
        return image

    @staticmethod
    def retransform(image):
        image = (image.transpose(1, 2, 0) + 1) / 2 * 10000
        return image.astype("uint16")

class DataModule(pl.LightningDataModule):    
    def __init__(self, gt_dir, cond_dir, batch_size=4, num_workers=0, val_size=0.15, size=256):
        super().__init__()
        self.gt_dir = gt_dir
        self.cond_dir = cond_dir
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.val_size = val_size
        self.size = size
        self.setup('fit')
    def setup(self, stage):
        all_images = sorted([u for u in os.listdir(self.cond_dir)])
        random.seed(42)
        random.shuffle(all_images)
        train_size = int((1-self.val_size)*len(all_images))
        train_images = all_images[:train_size]
        val_images = all_images[train_size:]
        test_size = int(0.3*len(val_images))
        test_images = val_images[:test_size]
        val_images = val_images[test_size:]
        self.train_ds = FinetuneData(self.gt_dir, self.cond_dir, train_images, self.size)
        self.val_ds = FinetuneData(self.gt_dir, self.cond_dir, val_images, self.size)
        self.test_ds = FinetuneData(self.gt_dir, self.cond_dir, test_images, self.size)
        print(f"Train size: {len(self.train_ds)}, Val size: {len(self.val_ds)}, Test size: {len(self.test_ds)}")
        print(f"Total size: {len(self.train_ds)+len(self.val_ds)+len(self.test_ds)}")
    def train_dataloader(self):
        return DataLoader(self.train_ds, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers)

    def val_dataloader(self):
        return DataLoader(self.val_ds, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers)

    def test_dataloader(self):
        return DataLoader(self.test_ds, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers)


def parse_args(**parser_kwargs):
    parser = argparse.ArgumentParser(**parser_kwargs)
    parser.add_argument('--checkpoint', type=str,
                        default="./logs/2024-11-20T15-34-10/testtube/version_0/checkpoints/epoch=360-step=249999.ckpt")
    parser.add_argument('--config', type=str, default="models/cldm_v15_sar2opt.yaml")
    parser.add_argument('--test_dir', type=str, default=None, help="data/SEN12_AGRI/test")
    parser.add_argument('--save_dir', type=str, default="test_samples/GRD", help="test_samples/**")

    return parser.parse_args()

def process(det, input_image, prompt, a_prompt, n_prompt, num_samples, image_resolution, detect_resolution, ddim_steps, guess_mode, strength, scale, seed, eta, low_threshold, high_threshold):
    global preprocessor

    # print('Prompt:', prompt)
    # print('Added Prompt:', a_prompt)
    # print('Negative Prompt:', n_prompt)

    if det == 'Canny':
        if not isinstance(preprocessor, CannyDetector):
            preprocessor = CannyDetector()

    with torch.no_grad():
        # input_image = HWC3(input_image)

        # if det == 'None':
        #     detected_map = input_image.copy()
        # else:
        #     detected_map = preprocessor(resize_image(input_image, detect_resolution), low_threshold, high_threshold)
        #     detected_map = HWC3(detected_map)

        # img = resize_image(input_image, image_resolution)
        detected_map = input_image
        H, W, C = input_image.shape

        # detected_map = cv2.resize(detected_map, (W, H), interpolation=cv2.INTER_LINEAR)

        control = torch.from_numpy(detected_map.copy()).float().cuda() / 5000 - 1
        
        # control = torch.from_numpy(detected_map.copy()).float().cuda()
        # control[control == 0] = 1
        # control = torch.log(control) / torch.log(torch.as_tensor(255.0))


        control = torch.stack([control for _ in range(num_samples)], dim=0)
        control = einops.rearrange(control, 'b h w c -> b c h w').clone()

        if seed == -1:
            seed = random.randint(0, 65535)
        seed_everything(seed)

        if config.save_memory:
            model.low_vram_shift(is_diffusing=False)

        cond = {"c_concat": [control], "c_crossattn": [model.get_learned_conditioning([prompt + ', ' + a_prompt] * num_samples)]}
        un_cond = {"c_concat": None if guess_mode else [control], "c_crossattn": [model.get_learned_conditioning([n_prompt] * num_samples)]}
        shape = (4, H // 8, W // 8)

        if config.save_memory:
            model.low_vram_shift(is_diffusing=True)

        model.control_scales = [strength * (0.825 ** float(12 - i)) for i in range(13)] if guess_mode else ([strength] * 13)
        # Magic number. IDK why. Perhaps because 0.825**12<0.01 but 0.826**12>0.01

        samples, intermediates = ddim_sampler.sample(ddim_steps, num_samples,
                                                    shape, cond, verbose=False, eta=eta,
                                                    unconditional_guidance_scale=scale,
                                                    unconditional_conditioning=un_cond)

        if config.save_memory:
            model.low_vram_shift(is_diffusing=False)

        x_samples = model.decode_first_stage(samples)
        x_samples = (einops.rearrange(x_samples, 'b c h w -> b h w c')).cpu().numpy()
        
        x_samples = (x_samples + 1) / 2 * 10000
        x_samples = x_samples.astype(np.uint16)
        
        x_samples = percent_linear(x_samples)

        results = [x_samples[i] for i in range(num_samples)]
    return [detected_map] + results


if __name__ == "__main__":
    args = parse_args()

    preprocessor = None
    model = create_model(args.config)
    from peft import model_add_rlrr
    model_add_rlrr(model)
    model.load_state_dict(load_state_dict(args.checkpoint, location='cuda'), strict=True)
    model = model.cuda()
    model.eval()
    ddim_sampler = DDIMSampler(model)

    ips = dict(
        det='None',
        input_image=None,
        prompt='',
        a_prompt='',
        n_prompt='',
        num_samples=1,
        image_resolution=256,
        detect_resolution=256,
        ddim_steps=50,
        guess_mode=False,
        strength=1.0,
        scale=9.0,
        seed=42,
        eta=1.0,
        low_threshold=100,  
        high_threshold=200
    )

    test_dir = args.test_dir
    save_dir = args.save_dir
    save_dir_gt = os.path.join(save_dir, "gt")
    save_dir_cond = os.path.join(save_dir, "input")
    save_dir_sample = os.path.join(save_dir, "sample")
    os.makedirs(save_dir_gt, exist_ok=True)
    os.makedirs(save_dir_cond, exist_ok=True)       
    os.makedirs(save_dir_sample, exist_ok=True)

    # for i, f_name in enumerate(os.listdir(os.path.join(test_dir, 'gt'))):
    #     print(f"====================> processing {i} / {len(os.listdir(os.path.join(test_dir, 'gt')))} <===================")       
    #     input_image = io.imread(os.path.join(test_dir, 'input', f_name))
    #     ips['input_image'] = input_image
    #     result = process(**ips)
        
    #     io.imsave(os.path.join(save_dir_gt, f_name), io.imread(os.path.join(test_dir, 'gt', f_name)))
    #     io.imsave(os.path.join(save_dir_cond, f_name), result[0])
    #     io.imsave(os.path.join(save_dir_sample, f_name), result[1])



    gt_dir = r"D:\crli\Data\GRD\S2_256"
    cond_dir = r"D:\crli\Data\GRD\S1_256"
    dataModule = DataModule(gt_dir, cond_dir, batch_size=1, val_size=0.0255)
    test_dataloader = dataModule.test_dataloader()

    for i, batch in enumerate(test_dataloader, start=1):
        print(f"====================> processing {i} / {len(dataModule.test_ds)} <===================")       
        f_name = batch["gt_name"][0]
        image = batch["image"][0].numpy()
        control = batch["hint"][0].numpy()

        # input_image = io.imread(os.path.join(test_dir, 'input', f_name))
        input_image = FinetuneData.retransform(control)
        ips['input_image'] = input_image
        result = process(**ips)
        
        io.imsave(os.path.join(save_dir_gt, f_name), percent_linear(FinetuneData.retransform(image)))
        io.imsave(os.path.join(save_dir_cond, f_name), result[0])
        io.imsave(os.path.join(save_dir_sample, f_name), result[1])
