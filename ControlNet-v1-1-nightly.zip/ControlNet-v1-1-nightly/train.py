from share import *

import os
import argparse
import datetime
import pytorch_lightning as pl
from pytorch_lightning import loggers as pl_loggers
from pytorch_lightning.callbacks import ModelCheckpoint
from torch.utils.data import DataLoader
from tutorial_dataset import load_data, load_tif_data, GRDDataModule, SEN12DataModule
from cldm.logger import ImageLogger
from cldm.model import create_model, load_state_dict
from pytorch_lightning import seed_everything
seed_everything(42)

from peft import model_add_ssf, model_add_rlrr, model_add_lora

def parse_args(**parser_kwargs):
    parser = argparse.ArgumentParser(**parser_kwargs)
    parser.add_argument('--peft', type=str, default="rlrr")
    parser.add_argument('--lr', type=float, default=1e-5)
    parser.add_argument('--sd_path', type=str, default="./models/control_sd15_ini.ckpt")
    parser.add_argument('--config', type=str, default="models/cldm_v15_sar2opt.yaml")
    parser.add_argument('--dataset', type=str, default="")
    parser.add_argument('--gt_dir', type=str, default=None)
    parser.add_argument('--cond_dir', type=str, default=None)
    parser.add_argument('--image_size', type=int, default=256)
    parser.add_argument('--batch_size', type=int, default=4)
    parser.add_argument('--num_workers', type=int, default=0)
    parser.add_argument('--resume', type=str, default=None)
    parser.add_argument('--every_n_train_steps', type=int, default=50000)
    parser.add_argument('--max_steps', type=int, default=250000)
    parser.add_argument('--save_top_k', type=int, default=1, help="-1: all; 0: nothing; 1: only one")
    parser.add_argument('--save_last', type=int, default=1)
    parser.add_argument('--logdir', type=str, default="logs")
    parser.add_argument('--ext', type=str, default="")

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    # Configs
    # sd_path = './models/control_sd15_ini_agri.ckpt'
    sd_path = args.sd_path
    batch_size = args.batch_size
    logger_freq = 5000
    learning_rate = args.lr
    sd_locked = True
    only_mid_control = False


    # First use cpu to load models. Pytorch Lightning will automatically move it to GPUs.
    model = create_model(args.config)
    model.load_state_dict(load_state_dict(sd_path, location='cpu'), strict=False)
    model.learning_rate = learning_rate
    model.sd_locked = sd_locked
    model.only_mid_control = only_mid_control

    if args.peft == "ssf":
        # model_add_ssf(model)
        model_add_ssf(model.model.diffusion_model)
    elif args.peft == "rlrr":
        model_add_rlrr(model)
    elif args.peft == "lora":
        model_add_lora(model)

    # import loralib as lora
    # lora.mark_only_lora_as_trainable(model, bias="lora_only")

    # Misc
    # train_path = os.path.join("./data", args.dataset, "train")

    # train_dataset = load_data(os.path.join(train_path, "input"), os.path.join(train_path, "gt"), args.image_size)
    # train_dataloader = DataLoader(train_dataset, num_workers=8, batch_size=batch_size, shuffle=True)

    # val_dataloader=None
    # if os.path.exists(os.path.join("./data", args.dataset, "val")):
    #     val_path = os.path.join("./data", args.dataset, "val")
    #     val_dataset = load_data(os.path.join(val_path, "input"), os.path.join(val_path, "gt"), args.image_size)
    #     val_dataloader = DataLoader(val_dataset, num_workers=8, batch_size=batch_size, shuffle=True)

    assert args.dataset in ("GRD", "SEN12")
    if args.dataset == "GRD":
        dataModule = GRDDataModule(args.gt_dir, args.cond_dir, batch_size=args.batch_size, num_workers=0)
    if args.dataset == "SEN12":
        dataModule = SEN12DataModule(args.gt_dir, args.cond_dir, batch_size=args.batch_size, num_workers=0)
    train_dataloader = dataModule.train_dataloader()
    val_dataloader = dataModule.val_dataloader()
    # test_dataloader = dataModule.test_dataloader()


    imageLogger = ImageLogger(batch_frequency=logger_freq)
    checkpoint_callback = ModelCheckpoint(
        monitor='val/loss_ema',
        #filename='sample-mnist-{epoch:02d}-{val_loss:.2f}',
        save_top_k=args.save_top_k,
        every_n_train_steps=args.every_n_train_steps,
        verbose=True,
        #mode='min',
        save_last=args.save_last
    )

    now = datetime.datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
    # logdir = os.path.join(args.logdir, now + '_control_sd15_ini_' + args.dataset)
    logdir = os.path.join(args.logdir, now+f"-{args.ext}")

    if args.resume:
        logdir = args.resume.split("/testtube")[0]

    logger = pl_loggers.TensorBoardLogger(save_dir=logdir, name='testtube')
    trainer = pl.Trainer(gpus=1, precision=32, callbacks=[imageLogger, checkpoint_callback], logger=logger, 
                resume_from_checkpoint=args.resume, 
                max_steps=args.max_steps
            )
    
    # Train!
    trainer.fit(model, 
                train_dataloader, 
                val_dataloader
            )
