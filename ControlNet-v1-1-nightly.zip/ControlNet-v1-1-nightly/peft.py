import torch
from torch import nn
from torch.nn import functional as F

# ======================= SSF =======================
def _set_submodule(model, target, module) :
    if target == "":
        raise ValueError("Cannot set the submodule without a target name!")

    atoms = target.split(".")
    name = atoms.pop(-1)
    mod = model

    for item in atoms:
        if not hasattr(mod, item):
            raise AttributeError(
                mod._get_name() + " has no attribute `" + item + "`"
            )

        mod = getattr(mod, item)

        # Use isinstance instead of type here to also handle subclass of nn.Module
        if not isinstance(mod, torch.nn.Module):
            raise AttributeError("`" + item + "` is not an nn.Module")

    setattr(mod, name, module)

def init_ssf_scale_shift(dim):
    scale = nn.Parameter(torch.ones(dim))
    shift = nn.Parameter(torch.zeros(dim))

    nn.init.normal_(scale, mean=1, std=.02)
    nn.init.normal_(shift, std=.02)

    return scale, shift

def ssf_ada(x, scale, shift):
    assert scale.shape == shift.shape
    if x.shape[-1] == scale.shape[0]:
        return x * scale + shift
    elif x.shape[1] == scale.shape[0]:
        return x * scale.view(1, -1, 1, 1) + shift.view(1, -1, 1, 1)
    else:
        raise ValueError('the input tensor shape does not match the shape of the scale factor.')

class Conv2d(nn.Module):
    def __init__(self, module):
        self.__dict__.update(module.__dict__)
        self.ssf_scale, self.ssf_shift = init_ssf_scale_shift(self.out_channels)
    
    def _conv_forward(self, input, weight, bias):
        if self.padding_mode != "zeros":
            return F.conv2d(
                F.pad(
                    input, self._reversed_padding_repeated_twice, mode=self.padding_mode
                ),
                weight,
                bias,
                self.stride,
                _pair(0),
                self.dilation,
                self.groups,
            )
        return F.conv2d(
            input, weight, bias, self.stride, self.padding, self.dilation, self.groups
        )

    def forward(self, x):
        x = self._conv_forward(x, self.weight, self.bias)
        return ssf_ada(x, self.ssf_scale, self.ssf_shift)

class Linear(nn.Module):
    def __init__(self, module):
        self.__dict__.update(module.__dict__)
        self.ssf_scale, self.ssf_shift = init_ssf_scale_shift(self.out_features)
    
    def forward(self, x):
        x = F.linear(x, self.weight, self.bias)
        return ssf_ada(x, self.ssf_scale, self.ssf_shift)

class GroupNorm(nn.Module):
    def __init__(self, module):
        self.__dict__.update(module.__dict__)
        self.ssf_scale, self.ssf_shift = init_ssf_scale_shift(self.num_channels)
    
    def forward(self, x):
        x =  F.group_norm(x, self.num_groups, self.weight, self.bias, self.eps)
        return ssf_ada(x, self.ssf_scale, self.ssf_shift)

class LayerNorm(nn.Module):
    def __init__(self, module):
        self.__dict__.update(module.__dict__)
        self.ssf_scale, self.ssf_shift = init_ssf_scale_shift(self.normalized_shape)
    
    def forward(self, x):
        x =  F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        return ssf_ada(x, self.ssf_scale, self.ssf_shift)

def model_add_ssf(model):
    key_list = [key for key, _ in model.named_parameters()]
    key_set = set()

    for key in key_list:
        i = key.rfind(".")
        key_set.add(key[:i])

    for key in key_set:
        module = model.get_submodule(key)
        
        if isinstance(module, nn.Conv2d):
            _set_submodule(model, key, Conv2d(module))
        elif isinstance(module, nn.Linear):
            _set_submodule(model, key, Linear(module))
        elif isinstance(module, nn.GroupNorm):
            _set_submodule(model, key, GroupNorm(module))
        elif isinstance(module, nn.LayerNorm):
            _set_submodule(model, key, LayerNorm(module))

    # 冻结非ssf参数
    for n, p in model.named_parameters():
        p.requires_grad = "ssf" in n

def get_training_state_dict(model):
    training_state_dict = dict()
    for n, p in model.named_parameters():
        # if "ssf" in n:
        if p.requires_grad:
            training_state_dict.update({n: p})
    
    return training_state_dict
# ======================= SSF =======================

# ======================= RLRR =======================
class RLRRLinear(nn.Module):
    def __init__(self, module):
        self.__dict__.update(module.__dict__)
        self.has_bias = self.bias is not None
        self.scale_col = nn.Parameter(torch.empty(1, self.in_features), requires_grad=True)
        self.scale_line = nn.Parameter(torch.empty(self.out_features, 1), requires_grad=True)
        self.shift_bias = nn.Parameter(torch.empty(1, self.out_features), requires_grad=True)

        nn.init.kaiming_uniform_(self.scale_col)
        nn.init.kaiming_uniform_(self.scale_line)
        nn.init.zeros_(self.shift_bias)

    def forward(self, x):
        weight = (self.weight * self.scale_col * self.scale_line) + self.weight
        bias = (self.bias + self.shift_bias) if self.has_bias else self.shift_bias
        return F.linear(x, weight, bias)

class RLRRConv(nn.Module):
    def __init__(self, module):
        self.__dict__.update(module.__dict__)
        self.has_bias = self.bias is not None
        self.k = self.kernel_size[0]
        self.scale_col = nn.Parameter(torch.empty(1, self.in_channels * self.k), requires_grad=True)
        self.scale_line = nn.Parameter(torch.empty(self.out_channels * self.k, 1), requires_grad=True)
        if self.has_bias:
            self.shift_bias = nn.Parameter(torch.empty(self.out_channels), requires_grad=True)
            nn.init.zeros_(self.shift_bias)

        nn.init.kaiming_uniform_(self.scale_col)
        nn.init.kaiming_uniform_(self.scale_line)

    def __convert(self, weight):
        weight = weight.permute(0, 2, 1, 3).reshape(self.out_channels * self.k, self.in_channels * self.k)
        weight = self.weight + self.__deconvert(weight * self.scale_line * self.scale_col)
        return weight
    
    def __deconvert(self, weight):
        return weight.reshape(self.out_channels, self.k, self.in_channels, self.k).permute(0, 2, 1, 3)

    def forward(self, x):
        weight = self.__convert(self.weight)
        bias = None
        if self.has_bias:
            bias = self.bias + self.shift_bias
        return F.conv2d(x, weight, bias, stride=self.stride, padding=self.padding)

def model_add_rlrr(model):
    # 冻结原始参数
    model.requires_grad_(False)
# 
    target_module = ["attn1", "ff.net", ]
    # target_module = ["attn1", "ff.net", "proj_in", "proj_out"
    #                  "in_layers", "emb_layers", "out_layers",
    #                  "input_blocks.0.0", "out.2"]
    key_list = [key for key, _ in model.named_modules()]

    for key in key_list:
        for tk in target_module:
            if tk in key:
                module = model.get_submodule(key)
                if isinstance(module, nn.Conv2d):
                    _set_submodule(model, key, RLRRConv(module))
                elif isinstance(module, nn.Linear):
                    _set_submodule(model, key, RLRRLinear(module))
# ======================= RLRR =======================
                    
# ======================= LORA =======================
import loralib as lora

def model_add_lora(model):
    target_module = ["to_q", "to_v"]
    key_list = [key for key, _ in model.named_modules()]

    for key in key_list:
        for tk in target_module:
            if tk in key:
                module = model.get_submodule(key)
                lora_layer = lora.Linear(
                    module.in_features, 
                    module.out_features,
                    r=16,
                    lora_alpha=16,
                    bias=module.bias is not None)
                lora_layer.load_state_dict(module.state_dict(), strict=False)
                _set_submodule(model, key, lora_layer)

    lora.mark_only_lora_as_trainable(model, "lora_only")
# ======================= LORA =======================