import torch
import torch.nn as nn
import pytorch_lightning as pl
import torch.nn.functional as F
import numpy as np
from contextlib import contextmanager

from taming.modules.vqvae.quantize import VectorQuantizer2 as VectorQuantizer

from ldm.modules.diffusionmodules.model import Encoder, ResnetBlock, make_attn, Downsample, Upsample, Normalize, nonlinearity
from ldm.modules.distributions.distributions import DiagonalGaussianDistribution

from ldm.util import instantiate_from_config
Conv2d = nn.Conv2d

# ===================== SAR Feature ====================
class SARFeatureExtractor(nn.Module):
    def __init__(self, *, ch, ch_mult=(1,2,4,4), num_res_blocks=1,
                  attn_resolutions, dropout=0.0, resamp_with_conv=True, in_channels, 
                  resolution, z_channels,
                  use_linear_attn=False, attn_type="vanilla", **ignore_kwargs):
        super().__init__()
        if use_linear_attn: attn_type = "linear"
        self.ch = ch
        self.temb_ch = 0
        self.num_resolutions = len(ch_mult)
        self.num_res_blocks = num_res_blocks
        self.resolution = resolution
        self.in_channels = in_channels

        # downsampling
        self.conv_in = Conv2d(in_channels, self.ch, kernel_size=3, stride=1, padding=1)

        curr_res = resolution
        in_ch_mult = tuple(ch_mult)+(4,)
        # self.in_ch_mult = in_ch_mult
        self.down = nn.ModuleList()
        for i_level in range(self.num_resolutions):
            block = nn.ModuleList()
            attn = nn.ModuleList()
            block_in = ch*ch_mult[i_level]
            block_out = ch*in_ch_mult[i_level+1]
            for i_block in range(self.num_res_blocks):
                block.append(ResnetBlock(in_channels=block_in, 
                                         out_channels=block_out,
                                         temb_channels=self.temb_ch,
                                         dropout=dropout))
                block_in = block_out
                if curr_res in attn_resolutions:
                    attn.append(make_attn(block_in, attn_type=attn_type))
            down = nn.Module()
            down.block = block
            down.attn = attn
            if i_level != self.num_resolutions-1:
                down.downsample = Downsample(block_in, resamp_with_conv)
                curr_res = curr_res // 2
            self.down.append(down)
        
        # middle
        self.mid = nn.Module()
        self.mid.block_1 = ResnetBlock(in_channels=block_in,
                                       out_channels=block_in,
                                       temb_channels=self.temb_ch,
                                       dropout=dropout)
        self.mid.attn_1 = make_attn(block_in, attn_type=attn_type)
        self.mid.block_2 = ResnetBlock(in_channels=block_in,
                                       out_channels=block_in,
                                       temb_channels=self.temb_ch,
                                       dropout=dropout)

        # end
        # self.norm_out = Normalize(block_in)
        # self.conv_out = Conv2d(block_in, block_in, kernel_size=3, stride=1, padding=1)
    
    def forward(self, x):
        pass

class Decoder(nn.Module):
    def __init__(self, *, ch, out_ch, ch_mult=(1,2,4,8), num_res_blocks,
                 attn_resolutions, dropout=0.0, resamp_with_conv=True, in_channels,
                 resolution, z_channels, give_pre_end=False, tanh_out=False, use_linear_attn=False,
                 attn_type="vanilla", **ignorekwargs):
        super().__init__()
        if use_linear_attn: attn_type = "linear"
        self.ch = ch
        self.temb_ch = 0
        self.num_resolutions = len(ch_mult)
        self.num_res_blocks = num_res_blocks
        self.resolution = resolution
        self.in_channels = in_channels
        self.give_pre_end = give_pre_end
        self.tanh_out = tanh_out

        # compute in_ch_mult, block_in and curr_res at lowest res
        in_ch_mult = (1,)+tuple(ch_mult)
        block_in = ch*ch_mult[self.num_resolutions-1]
        curr_res = resolution // 2**(self.num_resolutions-1)
        self.z_shape = (1,z_channels,curr_res,curr_res)
        print("Working with z of shape {} = {} dimensions.".format(
            self.z_shape, np.prod(self.z_shape)))

        # z to block_in
        self.conv_in = Conv2d(z_channels,
                                       block_in,
                                       kernel_size=3,
                                       stride=1,
                                       padding=1)

        # middle
        self.mid = nn.Module()
        self.mid.block_1 = ResnetBlock(in_channels=block_in,
                                       out_channels=block_in,
                                       temb_channels=self.temb_ch,
                                       dropout=dropout)
        self.mid.attn_1 = make_attn(block_in, attn_type=attn_type)
        self.mid.block_2 = ResnetBlock(in_channels=block_in,
                                       out_channels=block_in,
                                       temb_channels=self.temb_ch,
                                       dropout=dropout)

        # upsampling
        self.up = nn.ModuleList()
        for i_level in reversed(range(self.num_resolutions)):
            block = nn.ModuleList()
            attn = nn.ModuleList()
            block_out = ch*ch_mult[i_level]
            for i_block in range(self.num_res_blocks+1):
                block.append(ResnetBlock(in_channels=block_in,
                                         out_channels=block_out,
                                         temb_channels=self.temb_ch,
                                         dropout=dropout))
                block_in = block_out
                if curr_res in attn_resolutions:
                    attn.append(make_attn(block_in, attn_type=attn_type))
            up = nn.Module()
            up.block = block
            up.attn = attn
            if i_level != 0:
                up.upsample = Upsample(block_in, resamp_with_conv)
                curr_res = curr_res * 2
            self.up.insert(0, up) # prepend to get consistent order

        # end
        self.norm_out = Normalize(block_in)
        self.conv_out = Conv2d(block_in,
                                        out_ch,
                                        kernel_size=3,
                                        stride=1,
                                        padding=1)
        
        # ===================== SAR Feature ====================
        self.SARFE = SARFeatureExtractor(ch=ch, 
                                    ch_mult=ch_mult, 
                                    attn_resolutions=attn_resolutions, 
                                    dropout=dropout, 
                                    in_channels=in_channels,
                                    resolution=resolution,
                                    z_channels=z_channels)


    def forward(self, z, cond, temb=None):
        # ==========================================
        SARFE = self.SARFE
        # downsampling
        # print(sar.shape)
        h_in = SARFE.conv_in(cond)
        # print(h_in.shape)
        h_res = []
        h_downsample = []
        for i_level in range(SARFE.num_resolutions):
            if i_level == 0:
                h = SARFE.down[i_level].block[0](h_in, temb)
            else:
                h = SARFE.down[i_level].block[0](h_downsample[-1], temb)
            h_res.append(h)
            if  i_level != SARFE.num_resolutions-1:
                h_downsample.append(SARFE.down[i_level].downsample(h_res[-1]))
        
        # for i in range(len(h_res)):
        #     print(f"h_res[{i}]", h_res[i].shape)

        # for i in range(len(h_downsample)):
        #     print(f"h_downsample[{i}]", h_downsample[i].shape)

        # middle
        h = h_res[-1]
        h_mid = []
        h_mid.append(SARFE.mid.block_1(h, temb))
        h_mid.append(SARFE.mid.attn_1(h_mid[-1]))
        h_mid.append(SARFE.mid.block_2(h_mid[-1], temb))

        # for i in range(len(h_mid)):
        #     print(h_mid[i].shape)

        # end
        # h = h_mid[-1]
        # h = SARFE.norm_out(h)
        # h = nonlinearity(h)
        # h_out = SARFE.conv_out(h)

        # print(h_out.shape)
        # exit(1)
        # ==========================================

        #assert z.shape[1:] == self.z_shape[1:]
        self.last_z_shape = z.shape

        # timestep embedding
        temb = None

        # z to block_in
        h = self.conv_in(z)
        # h = self.conv_in(z) + h_out  # ++++++

        # middle
        h += h_mid[-1]
        h = self.mid.block_1(h, temb) + h_mid[-2]
        h = self.mid.attn_1(h) + h_mid[-3]
        h = self.mid.block_2(h, temb)

        # upsampling
        for i_level in reversed(range(self.num_resolutions)):
            h += h_res[i_level]  # ++++++
            for i_block in range(self.num_res_blocks+1):
                h = self.up[i_level].block[i_block](h, temb)
                if len(self.up[i_level].attn) > 0:
                    h = self.up[i_level].attn[i_block](h)
            if i_level != 0:
                # print(i_level)
                # print(h.shape, h_downsample[i_level-1].shape)
                h += h_downsample[i_level-1] # ++++++
                h = self.up[i_level].upsample(h)

        # end
        if self.give_pre_end:
            return h

        h = self.norm_out(h)
        h = nonlinearity(h)
        h = self.conv_out(h)
        if self.tanh_out:
            h = torch.tanh(h)
        return h


class AutoencoderKL(pl.LightningModule):
    def __init__(self,
                 ddconfig,
                 lossconfig,
                 embed_dim,
                 ckpt_path=None,
                 ignore_keys=[],
                 image_key="image",
                 cond_key="hint",
                 colorize_nlabels=None,
                 monitor=None,
                 ):
        super().__init__()
        self.image_key = image_key
        self.cond_key = cond_key
        self.encoder = Encoder(**ddconfig)
        self.decoder = Decoder(**ddconfig)
        self.loss = instantiate_from_config(lossconfig)
        assert ddconfig["double_z"]
        self.quant_conv = Conv2d(2*ddconfig["z_channels"], 2*embed_dim, 1)
        self.post_quant_conv = Conv2d(embed_dim, ddconfig["z_channels"], 1)
        self.embed_dim = embed_dim
        if colorize_nlabels is not None:
            assert type(colorize_nlabels)==int
            self.register_buffer("colorize", torch.randn(3, colorize_nlabels, 1, 1))
        if monitor is not None:
            self.monitor = monitor
        if ckpt_path is not None:
            self.init_from_ckpt(ckpt_path, ignore_keys=ignore_keys)
        self.mask = None

        # 冻结编码器
        self.encoder.requires_grad_(False)
        # for n, p in self.encoder.named_parameters():
            # if "scale_col" not in n and "scale_line" not in n:
            # p.requires_grad = False
        # 微调解码器
        # for n,p in self.decoder.named_parameters():
        #     if "scale_col" not in n and "scale_line" not in n and "conv_out" not in n:
        #         p.requires_grad = False

    def init_from_ckpt(self, path, ignore_keys=list()):
        sd = torch.load(path, map_location="cpu")["state_dict"]
        keys = list(sd.keys())
        for k in keys:
            for ik in ignore_keys:
                if k.startswith(ik):
                    print("Deleting key {} from state_dict.".format(k))
                    del sd[k]
        self.load_state_dict(sd, strict=False)

        for n, p in self.named_parameters():
            p.requires_grad = False

        print(f"Restored from {path}")

    def encode(self, x):
        h = self.encoder(x)
        moments = self.quant_conv(h)
        posterior = DiagonalGaussianDistribution(moments)
        return posterior

    def decode(self, z, cond):
        z = self.post_quant_conv(z)
        dec = self.decoder(z, cond)
        return dec

    def forward(self, input, cond, sample_posterior=True):
        posterior = self.encode(input)
        if sample_posterior:
            z = posterior.sample()
        else:
            z = posterior.mode()
        dec = self.decode(z, cond)
        return dec, posterior

    def get_input(self, batch, k):
        x = batch[k]
        if len(x.shape) == 3:
            x = x[..., None]
        # x = x.permute(0, 3, 1, 2).to(memory_format=torch.contiguous_format).float()
        x = x.to(memory_format=torch.contiguous_format).float()
        return x

    def training_step(self, batch, batch_idx, optimizer_idx):
        inputs = self.get_input(batch, self.image_key)
        conds = self.get_input(batch, self.cond_key)
        reconstructions, posterior = self(inputs, conds)
    
        if optimizer_idx == 0:
            # train encoder+decoder+logvar
            aeloss, log_dict_ae = self.loss(inputs, reconstructions, posterior, optimizer_idx, self.global_step,
                                            last_layer=self.get_last_layer(), split="train")
            self.log("aeloss", aeloss, prog_bar=True, logger=True, on_step=True, on_epoch=True)
            self.log_dict(log_dict_ae, prog_bar=False, logger=True, on_step=True, on_epoch=False)
            return aeloss

        if optimizer_idx == 1:
            # train the discriminator
            discloss, log_dict_disc = self.loss(inputs, reconstructions, posterior, optimizer_idx, self.global_step,
                                                last_layer=self.get_last_layer(), split="train")

            self.log("discloss", discloss, prog_bar=True, logger=True, on_step=True, on_epoch=True)
            self.log_dict(log_dict_disc, prog_bar=False, logger=True, on_step=True, on_epoch=False)
            return discloss

    @torch.no_grad()
    def validation_step(self, batch, batch_idx):
        inputs = self.get_input(batch, self.image_key)
        conds = self.get_input(batch, self.cond_key)
        reconstructions, posterior = self(inputs, conds)
        aeloss, log_dict_ae = self.loss(inputs, reconstructions, posterior, 0, self.global_step,
                                        last_layer=self.get_last_layer(), split="val")

        discloss, log_dict_disc = self.loss(inputs, reconstructions, posterior, 1, self.global_step,
                                            last_layer=self.get_last_layer(), split="val")

        self.log("val/rec_loss", log_dict_ae["val/rec_loss"])
        self.log_dict(log_dict_ae)
        self.log_dict(log_dict_disc)
        return self.log_dict

    def configure_optimizers(self):
        lr = self.learning_rate
        # opt_ae = torch.optim.Adam(list(self.encoder.parameters())+
        #                             list(self.decoder.parameters())+
        #                             list(self.quant_conv.parameters())+
        #                             list(self.post_quant_conv.parameters()),
        #                             lr=lr, betas=(0.5, 0.9))
        # 只训练解码器
        opt_ae = torch.optim.Adam(
                            list(self.decoder.parameters())+
                            list(self.post_quant_conv.parameters()),
                            lr=lr, betas=(0.5, 0.9))
        opt_disc = torch.optim.Adam(self.loss.discriminator.parameters(),
                                    lr=lr, betas=(0.5, 0.9))
        return [opt_ae, opt_disc], []

    def get_last_layer(self):
        return self.decoder.conv_out.weight


    @torch.no_grad()
    def log_images(self, batch, only_inputs=False, **kwargs):
        log = dict()
        x = self.get_input(batch, self.image_key)
        cond = self.get_input(batch, self.cond_key)
        x = x.to(self.device)
        cond = cond.to(self.device)
        if not only_inputs:
            xrec, posterior = self(x, cond)
            if x.shape[1] > 3:
                # colorize with random projection
                assert xrec.shape[1] > 3
                # x = self.to_rgb(x)
                # xrec = self.to_rgb(xrec)
            # log["samples"] = self.decode(torch.randn_like(posterior.sample()))
            log["reconstructions"] = xrec
        log["inputs"] = x
        log["diff"] = abs(x - xrec)
        return log

    def to_rgb(self, x):
        assert self.image_key == "segmentation"
        if not hasattr(self, "colorize"):
            self.register_buffer("colorize", torch.randn(3, x.shape[1], 1, 1).to(x))
        x = F.conv2d(x, weight=self.colorize)
        x = 2.*(x-x.min())/(x.max()-x.min()) - 1.
        return x

