import numpy as np
import torch
import torch.nn as nn
import pytorch_lightning as pl
import torch.nn.functional as F
from contextlib import contextmanager
from taming.modules.vqvae.quantize import VectorQuantizer2 as VectorQuantizer
from ldm.modules.diffusionmodules.model import Encoder, ResnetBlock, make_attn, Downsample, Upsample, Normalize, nonlinearity
from ldm.modules.distributions.distributions import DiagonalGaussianDistribution
from ldm.util import instantiate_from_config


#####################################################
####### The FCM with convolutional architecture #####
#####################################################
class NonResnetBlock(nn.Module):
    def __init__(self, in_c, out_c, dropout, num_groups=32):
        super().__init__()
        self.block = nn.Sequential(
            nn.GroupNorm(num_groups, in_c),
            nn.SiLU(),
            nn.Conv2d(in_c, out_c, kernel_size=3, stride=1, padding=1),
            nn.GroupNorm(num_groups, out_c),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Conv2d(out_c, out_c, kernel_size=3, stride=1, padding=1),
        )

        self.has_shortcut = (in_c != out_c)
        if self.has_shortcut:
            self.shortcut = nn.Conv2d(in_c, out_c, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        h = self.block(x)
        if self.has_shortcut:
            x = self.shortcut(x)

        return h

#####################################################
####### FCM with convolution, DSL non pair-wise #####
#####################################################
class Decoder(nn.Module):
    def __init__(
        self,
        *,
        ch=128,
        out_ch=3,
        ch_mult=[1, 1, 2, 2, 4],
        num_res_blocks=2,
        attn_resolutions=[16],
        dropout=0.0,
        resamp_with_conv=True,
        in_channels,
        resolution=256,
        z_channels=256,
        give_pre_end=False, 
        tanh_out=False, 
        use_linear_attn=False,
        kernel_size=9,
        dsl_init_sigma=3.0,
        num_groups=4,
        device="cuda",
        attn_type="vanilla",
        **ignorekwargs
    ):
        super().__init__()
        if use_linear_attn: attn_type = "linear"
        self.ch = ch
        self.temb_ch = 0
        self.num_resolutions = len(ch_mult)
        self.num_res_blocks = num_res_blocks
        self.resolution = resolution
        self.in_channels = in_channels
        self.give_pre_end = give_pre_end
        self.tanh_out = tanh_out

        # number of channels at lowest res
        block_in = ch*ch_mult[self.num_resolutions-1]
        curr_res = resolution // 2**(self.num_resolutions-1)
        self.z_shape = (1,z_channels,curr_res,curr_res)
        print("Working with z of shape {} = {} dimensions.".format(
            self.z_shape, np.prod(self.z_shape)))

        print("\nDECODER SETTING: with non pairwise DSL")
        self.device = device
        self.kernel_size = kernel_size
        self.sigmas = nn.Parameter(torch.tensor([dsl_init_sigma, dsl_init_sigma, dsl_init_sigma, dsl_init_sigma]), requires_grad=True)
        self.padding = [kernel_size // 2, kernel_size // 2, kernel_size // 2, kernel_size // 2]

      

        # z to block_in
        self.fcm_1 = NonResnetBlock(z_channels, z_channels, dropout=dropout, num_groups=num_groups)
        self.conv_in = nn.Conv2d(z_channels, block_in, kernel_size=3, stride=1, padding=1)

        self.fcm_2 = NonResnetBlock(block_in, block_in, dropout=dropout)
        # middle
        self.mid = nn.Module()
        self.mid.block_1 = ResnetBlock(in_channels=block_in,
                                       out_channels=block_in,
                                       temb_channels=self.temb_ch,
                                       dropout=dropout)
        self.mid.attn_1 = make_attn(block_in, attn_type=attn_type)
        self.mid.block_2 = ResnetBlock(in_channels=block_in,
                                       out_channels=block_in,
                                       temb_channels=self.temb_ch,
                                       dropout=dropout)

        self.fcm_3 = NonResnetBlock(block_in, block_in, dropout=dropout)
        # upsampling
        self.up = nn.ModuleList()
        for i_level in reversed(range(self.num_resolutions)):
            block = nn.ModuleList()
            attn = nn.ModuleList()
            block_out = ch*ch_mult[i_level]
            for i_block in range(self.num_res_blocks+1):
                block.append(ResnetBlock(in_channels=block_in,
                                         out_channels=block_out,
                                         temb_channels=self.temb_ch,
                                         dropout=dropout))
                block_in = block_out
                if curr_res in attn_resolutions:
                    attn.append(make_attn(block_in, attn_type=attn_type))
            up = nn.Module()
            up.block = block
            up.attn = attn
            if i_level != 0:
                up.upsample = Upsample(block_in, resamp_with_conv)
                curr_res = curr_res * 2
            self.up.insert(0, up) # prepend to get consistent order

        self.fcm_4 = NonResnetBlock(block_in, block_in, dropout=dropout)
        # end
        self.norm_out = Normalize(block_in)
        self.conv_out = torch.nn.Conv2d(block_in,
                                        out_ch,
                                        kernel_size=3,
                                        stride=1,
                                        padding=1)


    def _get_gaussian_kernel1d(self, kernel_size, sigma, device):
        ksize_half = (kernel_size - 1) * 0.5
        x = torch.linspace(-ksize_half, ksize_half, steps=kernel_size).to(device)
        pdf = torch.exp(-0.5 * (x / sigma).pow(2))
        kernel1d = pdf / pdf.sum()

        return kernel1d


    def _get_gaussian_kernel2d(self, kernel_size, sigma, dtype, device):
        kernel1d_y = self._get_gaussian_kernel1d(kernel_size, sigma, device)
        kernel1d_y = kernel1d_y.unsqueeze(1)
        kernel2d = torch.matmul(kernel1d_y, kernel1d_y.t())
        return kernel2d

    def _gaussian_blur(self, x, i):
        self.gauss_kernel = self._get_gaussian_kernel2d(self.kernel_size, self.sigmas[i], dtype=torch.float, device=self.device)
        self.gauss_kernel = self.gauss_kernel.repeat(x.shape[-3],1,1,1)
        x = F.pad(x, self.padding, mode="reflect")
        feat = F.conv2d(x, self.gauss_kernel, groups=x.shape[-3])

        return feat


    def forward(self, z, inference=False):
        # timestep embedding
        temb = None
        
        feat = None
        inter_features = []    
        h = self.fcm_1(z)               
        if not inference:
            feat = self._gaussian_blur(h, 0)
        else:
            feat = h
        
        inter_features.append(feat)
        h = h + z

        h_ = self.conv_in(h)             
        h = self.fcm_2(h_)               

        if not inference:
            feat = self._gaussian_blur(h, 1)
        else:
            feat = h
        inter_features.append(feat)
        h_ = h_ + h

        # h_ = self.mid(h_)              
        # middle
        h_ = self.mid.block_1(h_, temb)
        h_ = self.mid.attn_1(h_)
        h_ = self.mid.block_2(h_, temb)
   
        h = self.fcm_3(h_)              

        if not inference:
            feat = self._gaussian_blur(h, 2)
        else:
            feat = h
        inter_features.append(feat)
        h_ = h_ + h

        # h_ = self.up(h_)      
        # upsampling
        for i_level in reversed(range(self.num_resolutions)):
            for i_block in range(self.num_res_blocks+1):
                h_ = self.up[i_level].block[i_block](h_, temb)
                if len(self.up[i_level].attn) > 0:
                    h_ = self.up[i_level].attn[i_block](h_)
            if i_level != 0:
                h_ = self.up[i_level].upsample(h_)
                            
        h = self.fcm_4(h_)               

        if not inference:
            feat = self._gaussian_blur(h, 3)
        else:
            feat = h
        inter_features.append(feat)
        h_ = h_ + h
        
        # h = self.final(h_)     
        # end
        if self.give_pre_end:
            return h_

        h = self.norm_out(h_)
        h = nonlinearity(h)
        h = self.conv_out(h)
        if self.tanh_out:
            h = torch.tanh(h)        

        return h, inter_features

    # def forward(self, z):
    #     #assert z.shape[1:] == self.z_shape[1:]
    #     self.last_z_shape = z.shape

    #     # timestep embedding
    #     temb = None

    #     # z to block_in
    #     h = self.conv_in(z)

    #     # middle
    #     h = self.mid.block_1(h, temb)
    #     h = self.mid.attn_1(h)
    #     h = self.mid.block_2(h, temb)

    #     # upsampling
    #     for i_level in reversed(range(self.num_resolutions)):
    #         for i_block in range(self.num_res_blocks+1):
    #             h = self.up[i_level].block[i_block](h, temb)
    #             if len(self.up[i_level].attn) > 0:
    #                 h = self.up[i_level].attn[i_block](h)
    #         if i_level != 0:
    #             h = self.up[i_level].upsample(h)

    #     # end
    #     if self.give_pre_end:
    #         return h

    #     h = self.norm_out(h)
    #     h = nonlinearity(h)
    #     h = self.conv_out(h)
    #     if self.tanh_out:
    #         h = torch.tanh(h)
    #     return h


class AutoencoderKL(pl.LightningModule):
    def __init__(self,
                 ddconfig,
                 lossconfig,
                 embed_dim,
                 ckpt_path=None,
                 ignore_keys=[],
                 image_key="image",
                 colorize_nlabels=None,
                 monitor=None,
                 ):
        super().__init__()
        self.image_key = image_key
        self.encoder = Encoder(**ddconfig)
        self.decoder = Decoder(**ddconfig)
        self.loss = instantiate_from_config(lossconfig)
        assert ddconfig["double_z"]
        self.quant_conv = nn.Conv2d(2*ddconfig["z_channels"], 2*embed_dim, 1)
        self.post_quant_conv = nn.Conv2d(embed_dim, ddconfig["z_channels"], 1)
        self.embed_dim = embed_dim
        if colorize_nlabels is not None:
            assert type(colorize_nlabels)==int
            self.register_buffer("colorize", torch.randn(3, colorize_nlabels, 1, 1))
        if monitor is not None:
            self.monitor = monitor
        if ckpt_path is not None:
            self.init_from_ckpt(ckpt_path, ignore_keys=ignore_keys)
        self.mask = None

        # 冻结编码器
        self.encoder.requires_grad_(False)


    def init_from_ckpt(self, path, ignore_keys=list()):
        sd = torch.load(path, map_location="cpu")["state_dict"]
        keys = list(sd.keys())
        for k in keys:
            for ik in ignore_keys:
                if k.startswith(ik):
                    print("Deleting key {} from state_dict.".format(k))
                    del sd[k]
        self.load_state_dict(sd, strict=False)

        for n, p in self.named_parameters():
            p.requires_grad = False

        print(f"Restored from {path}")

    def encode(self, x):
        h = self.encoder(x)
        moments = self.quant_conv(h)
        posterior = DiagonalGaussianDistribution(moments)
        return posterior

    def decode(self, z, inference=True):
        z = self.post_quant_conv(z)
        dec, inter_features = self.decoder(z, inference)
        return dec, inter_features

    def forward(self, input, inference=True, sample_posterior=True):
        posterior = self.encode(input)
        if sample_posterior:
            z = posterior.sample()
        else:
            z = posterior.mode()
        dec, _ = self.decode(z, inference)
        return dec, posterior

    def get_input(self, batch, k):
        x = batch[k]
        if len(x.shape) == 3:
            x = x[..., None]
        # x = x.permute(0, 3, 1, 2).to(memory_format=torch.contiguous_format).float()
        x = x.to(memory_format=torch.contiguous_format).float()
        return x

    def training_step(self, batch, batch_idx, optimizer_idx):
        inputs = self.get_input(batch, self.image_key)
        reconstructions, posterior = self(inputs, inference=False)
    
        if optimizer_idx == 0:
            # train encoder+decoder+logvar
            aeloss, log_dict_ae = self.loss(inputs, reconstructions, posterior, optimizer_idx, self.global_step,
                                            last_layer=self.get_last_layer(), split="train")
            self.log("aeloss", aeloss, prog_bar=True, logger=True, on_step=True, on_epoch=True)
            self.log_dict(log_dict_ae, prog_bar=False, logger=True, on_step=True, on_epoch=False)
            return aeloss

        if optimizer_idx == 1:
            # train the discriminator
            discloss, log_dict_disc = self.loss(inputs, reconstructions, posterior, optimizer_idx, self.global_step,
                                                last_layer=self.get_last_layer(), split="train")

            self.log("discloss", discloss, prog_bar=True, logger=True, on_step=True, on_epoch=True)
            self.log_dict(log_dict_disc, prog_bar=False, logger=True, on_step=True, on_epoch=False)
            return discloss

    @torch.no_grad()
    def validation_step(self, batch, batch_idx):
        inputs = self.get_input(batch, self.image_key)
        reconstructions, posterior = self(inputs)
        aeloss, log_dict_ae = self.loss(inputs, reconstructions, posterior, 0, self.global_step,
                                        last_layer=self.get_last_layer(), split="val")

        discloss, log_dict_disc = self.loss(inputs, reconstructions, posterior, 1, self.global_step,
                                            last_layer=self.get_last_layer(), split="val")

        self.log("val/rec_loss", log_dict_ae["val/rec_loss"])
        self.log_dict(log_dict_ae)
        self.log_dict(log_dict_disc)
        return self.log_dict

    def configure_optimizers(self):
        lr = self.learning_rate
        # opt_ae = torch.optim.Adam(list(self.encoder.parameters())+
        #                             list(self.decoder.parameters())+
        #                             list(self.quant_conv.parameters())+
        #                             list(self.post_quant_conv.parameters()),
        #                             lr=lr, betas=(0.5, 0.9))
        # 只训练解码器
        opt_ae = torch.optim.Adam(
                            list(self.decoder.parameters())+
                            list(self.post_quant_conv.parameters()),
                            lr=lr, betas=(0.5, 0.9))
        opt_disc = torch.optim.Adam(self.loss.discriminator.parameters(),
                                    lr=lr, betas=(0.5, 0.9))
        return [opt_ae, opt_disc], []

    def get_last_layer(self):
        return self.decoder.conv_out.weight


    @torch.no_grad()
    def log_images(self, batch, only_inputs=False, **kwargs):
        log = dict()
        x = self.get_input(batch, self.image_key)
        x = x.to(self.device)
        if not only_inputs:
            xrec, posterior = self(x)
            if x.shape[1] > 3:
                # colorize with random projection
                assert xrec.shape[1] > 3
                x = self.to_rgb(x)
                xrec = self.to_rgb(xrec)
            # log["samples"] = self.decode(torch.randn_like(posterior.sample()))
            log["reconstructions"] = xrec
        log["inputs"] = x
        log["diff"] = abs(x - xrec)
        return log

    def to_rgb(self, x):
        assert self.image_key == "segmentation"
        if not hasattr(self, "colorize"):
            self.register_buffer("colorize", torch.randn(3, x.shape[1], 1, 1).to(x))
        x = F.conv2d(x, weight=self.colorize)
        x = 2.*(x-x.min())/(x.max()-x.min()) - 1.
        return x
