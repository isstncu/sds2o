import numpy as np
import random
import string
from torch.utils.data import Dataset, DataLoader
import blobfile as bf
from PIL import Image
import skimage.io as io
import math
import tifffile as tiff


def _list_image_files_recursively(data_dir):
    results = []
    for entry in sorted(bf.listdir(data_dir)):
        full_path = bf.join(data_dir, entry)
        ext = entry.split(".")[-1]
        if "." in entry and ext.lower() in ["jpg", "jpeg", "png", "gif", 'tif']:
            results.append(full_path)
        elif bf.isdir(full_path):
            results.extend(_list_image_files_recursively(full_path))
    return results

def center_crop_arr(pil_image, image_size):
    # We are not on a new enough PIL to support the `reducing_gap`
    # argument, which uses BOX downsampling at powers of two first.
    # Thus, we do it by hand to improve downsample quality.
    while min(*pil_image.size) >= 2 * image_size:
        pil_image = pil_image.resize(
            tuple(x // 2 for x in pil_image.size), resample=Image.BOX
        )

    scale = image_size / min(*pil_image.size)
    pil_image = pil_image.resize(
        tuple(round(x * scale) for x in pil_image.size), resample=Image.BICUBIC
    )

    arr = np.array(pil_image)
    crop_y = (arr.shape[0] - image_size) // 2
    crop_x = (arr.shape[1] - image_size) // 2
    return arr[crop_y : crop_y + image_size, crop_x : crop_x + image_size]

def random_crop_arr(pil_image, image_size, min_crop_frac=0.8, max_crop_frac=1.0):
    min_smaller_dim_size = math.ceil(image_size / max_crop_frac)
    max_smaller_dim_size = math.ceil(image_size / min_crop_frac)
    smaller_dim_size = random.randrange(min_smaller_dim_size, max_smaller_dim_size + 1)

    # We are not on a new enough PIL to support the `reducing_gap`
    # argument, which uses BOX downsampling at powers of two first.
    # Thus, we do it by hand to improve downsample quality.
    while min(*pil_image.size) >= 2 * smaller_dim_size:
        pil_image = pil_image.resize(
            tuple(x // 2 for x in pil_image.size), resample=Image.BOX
        )

    scale = smaller_dim_size / min(*pil_image.size)
    pil_image = pil_image.resize(
        tuple(round(x * scale) for x in pil_image.size), resample=Image.BICUBIC
    )

    arr = np.array(pil_image)
    crop_y = random.randrange(arr.shape[0] - image_size + 1)
    crop_x = random.randrange(arr.shape[1] - image_size + 1)
    return arr[crop_y : crop_y + image_size, crop_x : crop_x + image_size]

def load_data(
    *,
    data_dir_sar,
    data_dir_opt,
    batch_size,
    image_size,
    class_cond=False,
    deterministic=False,
    random_crop=False,
    random_flip=False,
):
    """
    For a dataset, create a generator over (images, kwargs) pairs.

    Each images is an NCHW float tensor, and the kwargs dict contains zero or
    more keys, each of which map to a batched Tensor of their own.
    The kwargs dict can be used for class labels, in which case the key is "y"
    and the values are integer tensors of class labels.

    :param data_dir: a dataset directory.
    :param batch_size: the batch size of each returned pair.
    :param image_size: the size to which images are resized.
    :param class_cond: if True, include a "y" key in returned dicts for class
                       label. If classes are not available and this is true, an
                       exception will be raised.
    :param deterministic: if True, yield results in a deterministic order.
    :param random_crop: if True, randomly crop the images for augmentation.
    :param random_flip: if True, randomly flip the images for augmentation.
    """
    print("data_dir_sar: ", data_dir_sar)
    print("data_dir_opt: ", data_dir_opt)
    if not data_dir_sar or not data_dir_opt:
        raise ValueError("unspecified data directory")

    all_files_sar = _list_image_files_recursively(data_dir_sar)
    all_files_opt = _list_image_files_recursively(data_dir_opt)
    classes = None
    #
    all_files_sar.sort(key=lambda x: int(x[len(data_dir_sar) + 1:].split('.')[0]))
    all_files_opt.sort(key=lambda x: int(x[len(data_dir_opt) + 1:].split('.')[0]))

    if class_cond:
        # Assume classes are the first part of the filename,
        # before an underscore.
        class_names = [bf.basename(path).split("_")[0] for path in data_dir_opt]
        sorted_classes = {x: i for i, x in enumerate(sorted(set(class_names)))}
        classes = [sorted_classes[x] for x in class_names]
    dataset = ImageDataset(
        image_size,
        all_files_sar,
        all_files_opt,
        classes=classes,
        random_crop=random_crop,
        random_flip=random_flip,
    )
    return dataset

class ImageDataset(Dataset):
    def __init__(
        self,
        resolution,
        image_paths_sar,
        image_paths_opt,
        classes=None,
        shard=0,
        num_shards=1,
        random_crop=False,
        random_flip=True,
    ):
        super().__init__()
        self.resolution = resolution
        self.local_images_sar = image_paths_sar[shard:][::num_shards]
        self.local_images_opt = image_paths_opt[shard:][::num_shards]
        self.local_classes = None if classes is None else classes[shard:][::num_shards]
        self.random_crop = random_crop
        self.random_flip = random_flip

    def __len__(self):
        return len(self.local_images_sar)

    def __getitem__(self, idx):
        path_sar = self.local_images_sar[idx]
        path_opt = self.local_images_opt[idx]
        with bf.BlobFile(path_sar, "rb") as f:
            pil_image_sar = Image.open(f)
            pil_image_sar.load()
        pil_image_sar = pil_image_sar.convert("RGB")
        with bf.BlobFile(path_opt, "rb") as f:
            pil_image_opt = Image.open(f)
            pil_image_opt.load()
        pil_image_opt = pil_image_opt.convert("RGB")

        if self.random_crop:
            arr_sar = random_crop_arr(pil_image_sar, self.resolution)
            arr_opt = random_crop_arr(pil_image_opt, self.resolution)
        else:
            arr_sar = center_crop_arr(pil_image_sar, self.resolution)
            arr_opt = center_crop_arr(pil_image_opt, self.resolution)

        if self.random_flip and random.random() < 0.5:
            arr_sar = arr_sar[:, ::-1]
            arr_opt = arr_opt[:, ::-1]

        arr_sar = arr_sar.astype(np.float32) / 127.5 - 1
        arr_opt = arr_opt.astype(np.float32) / 127.5 - 1
        out_dict = {}
        if self.local_classes is not None:
            out_dict["y"] = np.array(self.local_classes[idx], dtype=np.int64)
        arr_sar = np.transpose(arr_sar, [2, 0, 1])
        arr_opt = np.transpose(arr_opt, [2, 0, 1])
        arr = np.concatenate((arr_opt, arr_sar), axis=0)
        return arr, out_dict

def load_opt_data(
    data_dir_opt,
    image_size,
    class_cond=False,
    random_crop=False,
    random_flip=False,
):
    print("data_dir_opt: ", data_dir_opt)

    all_files_opt = _list_image_files_recursively(data_dir_opt)
    classes = None
    
    # all_files_opt.sort(key=lambda x: int(x[len(data_dir_opt) + 1:].split('.')[0]))

    if class_cond:
        # Assume classes are the first part of the filename,
        # before an underscore.
        class_names = [bf.basename(path).split("_")[0] for path in data_dir_opt]
        sorted_classes = {x: i for i, x in enumerate(sorted(set(class_names)))}
        classes = [sorted_classes[x] for x in class_names]
    dataset = OptDataset(
        image_size,
        all_files_opt,
        classes=classes,
        random_crop=random_crop,
        random_flip=random_flip,
    )
    return dataset

class OptDataset(Dataset):
    def __init__(
        self,
        resolution,
        image_paths_opt,
        classes=None,
        shard=0,
        num_shards=1,
        random_crop=False,
        random_flip=True,
    ):
        super().__init__()
        self.resolution = resolution
        self.local_images_opt = image_paths_opt[shard:][::num_shards]
        self.local_classes = None if classes is None else classes[shard:][::num_shards]
        self.random_crop = random_crop
        self.random_flip = random_flip

    def __len__(self):
        # return 8
        return len(self.local_images_opt)

    def __getitem__(self, idx):
        path_opt = self.local_images_opt[idx]

        with bf.BlobFile(path_opt, "rb") as f:
            pil_image_opt = Image.open(f)
            pil_image_opt.load()
        pil_image_opt = pil_image_opt.convert("RGB")

        if self.random_crop:
            arr_opt = random_crop_arr(pil_image_opt, self.resolution)
        else:
            arr_opt = center_crop_arr(pil_image_opt, self.resolution)

        if self.random_flip and random.random() < 0.5:
            arr_opt = arr_opt[:, ::-1]

        arr_opt = arr_opt.astype(np.float32) / 127.5 - 1
        out_dict = {}
        if self.local_classes is not None:
            out_dict["y"] = np.array(self.local_classes[idx], dtype=np.int64)
        # arr_opt = np.transpose(arr_opt, [2, 0, 1])
        return {'image': arr_opt, 'txt': ''}

def load_tif_data(
    data_dir_opt,
    image_size,
    class_cond=False,
    random_crop=False,
    random_flip=False,
):
    # print("data_dir_opt: ", data_dir_opt)

    all_files_opt = _list_image_files_recursively(data_dir_opt)
    classes = None
    #
    #all_files_opt.sort(key=lambda x: int(x[len(data_dir_opt) + 1:].split('.')[0]))

    if class_cond:
        # Assume classes are the first part of the filename,
        # before an underscore.
        class_names = [bf.basename(path).split("_")[0] for path in data_dir_opt]
        sorted_classes = {x: i for i, x in enumerate(sorted(set(class_names)))}
        classes = [sorted_classes[x] for x in class_names]
    dataset = TifDataset(
        # image_size,
        all_files_opt,
        classes=classes,
        random_crop=random_crop,
        random_flip=random_flip,
    )
    return dataset

class TifDataset(Dataset):
    def __init__(
        self,
        # resolution,
        image_paths_opt,
        classes=None,
        shard=0,
        num_shards=1,
        random_crop=False,
        random_flip=True,
    ):
        super().__init__()
        # self.resolution = resolution
        self.local_images_opt = image_paths_opt[shard:][::num_shards]
        self.local_classes = None if classes is None else classes[shard:][::num_shards]
        self.random_crop = random_crop
        self.random_flip = random_flip

    def __len__(self):
        return len(self.local_images_opt)

    def __getitem__(self, idx):
        path_opt = self.local_images_opt[idx]
        
        arr_opt = io.imread(path_opt)[:, :, :3]  # 取前三个通道
        arr_opt = arr_opt[:, :, ::-1]
        # arr_opt = arr_opt.astype(np.float32) / 127.5 - 1
        arr_opt = arr_opt.astype(np.float32) / 5000 - 1

        # arr_opt = tiff.imread(path_opt)
        # arr_opt[arr_opt == 0] = 1
        # arr_opt = np.log(arr_opt) / np.log(255.0)
        # arr_opt = arr_opt.astype(np.float32)
        return {'image': arr_opt, 'txt': ''}


import os
import random
import skimage.io as io
import pytorch_lightning as pl
from torch.utils.data import Dataset, DataLoader


def load_finetune_data(type,
                       gt_dir, 
                       cond_dir, 
                       batch_size=4, 
                       num_workers=0, 
                       val_size=0.15, 
                       size=256):
    assert type in ("train", "val", "test")
    dataModule = DataModule(gt_dir, cond_dir, batch_size, num_workers, val_size, size)
    if type == "train":
        return dataModule.train_ds
    elif type == "val":
        return dataModule.val_ds

class FinetuneData(Dataset):
    def __init__(self, gt_dir, cond_dir, cond_images, size=256):
        self.gt_dir = gt_dir
        self.cond_dir = cond_dir
        self.gt_list = os.listdir(gt_dir)
        self.cond_list = cond_images
        self.size = size
        self.pair= {
         "S1_20220719":      "S2_20220719",    
         "S1_20220907":      "S2_20220907",    
         "S1_20220921":      "S2_20220922",    
         "S1_20221019":      "S2_20221018",    
         "S1_20221028":      "S2_20221028",    
         "S1_20221031":      "S2_20221101",    
         "S1_20221103":      "S2_20221103",    
         "S1_20221104":      "S2_20221104",    
         "S1_20221112":      "S2_20221113",    
         "S1_20221125":      "S2_20221125",    
         "S1_20221129":      "S2_20221128",    
         "S1_20221218_18":   "S2_20221218_18",
         "S1_20221218_19":   "S2_20221218_19",
         "S1_20221222":      "S2_20221221",    
         "S1_20221230":      "S2_20221231",    
        }
    def __len__(self):
        return len(self.cond_list)
    def __getitem__(self, idx):
        cond_name = self.cond_list[idx]
        # cond = io.imread(os.path.join(self.cond_dir, cond_name))
        gt_name = self.pair[cond_name.split("-")[0]] + "-" + cond_name.split("-")[1]
        gt = io.imread(os.path.join(self.gt_dir, gt_name))
        gt = gt[:, :, :3][:, :, ::-1]
        # return dict(image=self.transform(gt), 
        #             hint=self.transform(cond), 
        #             txt='',
        #             gt_name=self.gt_list[idx])
        return dict(image=gt, txt='')
    
    # def transform(self, image):
    #     image = image.transpose(2, 0, 1).astype("float32") / 5000 - 1
    #     return image

class DataModule(pl.LightningDataModule):    
    def __init__(self, gt_dir, cond_dir, batch_size=4, num_workers=0, val_size=0.15, size=256):
        super().__init__()
        self.gt_dir = gt_dir
        self.cond_dir = cond_dir
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.val_size = val_size
        self.size = size
        self.setup('fit')
    def setup(self, stage):
        all_images = sorted([u for u in os.listdir(self.cond_dir)])
        random.seed(42)
        random.shuffle(all_images)
        train_size = int((1-self.val_size)*len(all_images))
        train_images = all_images[:train_size]
        val_images = all_images[train_size:]
        test_size = int(0.3*len(val_images))
        test_images = val_images[:test_size]
        val_images = val_images[test_size:]
        self.train_ds = FinetuneData(self.gt_dir, self.cond_dir, train_images, self.size)
        self.val_ds = FinetuneData(self.gt_dir, self.cond_dir, val_images, self.size)
        self.test_ds = FinetuneData(self.gt_dir, self.cond_dir, test_images, self.size)
        print(f"Train size: {len(self.train_ds)}, Val size: {len(self.val_ds)}, Test size: {len(self.test_ds)}")
        print(f"Total size: {len(self.train_ds)+len(self.val_ds)+len(self.test_ds)}")
    def train_dataloader(self):
        return DataLoader(self.train_ds, batch_size=self.batch_size, shuffle=True, num_workers=self.num_workers)

    def val_dataloader(self):
        return DataLoader(self.val_ds, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers)

    def test_dataloader(self):
        return DataLoader(self.test_ds, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers)
