# python tool_add_control.py ./models/v1-5-pruned.ckpt ./models/control_sd15_ini.ckpt

python tool_add_control.py ../pokemon-sd/sd-lora/logs/2024-06-12T10-01-46_opt/checkpoints/last.ckpt ./models/control_sd15_ini_SEN12_URBAN.ckpt

CUDA_VISIBLE_DEVICES=2 \
python train.py --sd_path ./models/control_sd15_ini_SEN12_URBAN.ckpt \
    --dataset SEN12_URBAN \
    --save_top_k -1 \
    --resume logs/2024-06-13T10-04-11_control_sd15_ini_SEN12_URBAN/testtube/version_0/checkpoints/epoch=399-step=249999.ckpt



CUDA_VISIBLE_DEVICES=1 \
python tool_add_control.py ../pokemon-sd/sd-lora/logs/2024-06-12T21-23-59_sar/checkpoints/last.ckpt ./models/control_sd15_ini_full_pool_puali.ckpt

CUDA_VISIBLE_DEVICES=1 \
python train.py --sd_path ./models/control_sd15_ini_full_pool_puali.ckpt \
    --dataset /home/jbwei/Pke/full_pol_puali \
    --save_top_k -1


CUDA_VISIBLE_DEVICES=1 \
python tool_add_control.py ../pokemon-sd/sd-lora/logs/2024-06-17T14-54-52_sar/checkpoints/last.ckpt ./models/control_sd15_ini_sar.ckpt

CUDA_VISIBLE_DEVICES=1 \
python train.py --sd_path ./models/control_sd15_ini_sar.ckpt \
    --dataset /home/jbwei/Pke/3channel_sar \
    --save_top_k -1


CUDA_VISIBLE_DEVICES=2 \
python tool_add_control.py ../pokemon-sd/sd-lora/logs/2024-06-20T18-48-01_opt/checkpoints/last.ckpt ./models/control_sd15_ini_opt_wmse.ckpt

CUDA_VISIBLE_DEVICES=2 \
python train.py --sd_path ./models/control_sd15_ini_opt_wmse.ckpt \
    --dataset /home/jbwei/Pke/data/synthesis \
    --save_top_k -1
    

# ==========================================================================
CUDA_VISIBLE_DEVICES=1 \
python tool_add_control.py ../pokemon-sd/sd-lora/logs/2024-06-21T17-47-38_opt/checkpoints/last.ckpt ./models/control_sd15_ini_opt_alpha.ckpt

CUDA_VISIBLE_DEVICES=1 \
python train.py --sd_path ./models/control_sd15_ini_opt_alpha.ckpt \
    --dataset SEN12_URBAN \
    --save_top_k 1

CUDA_VISIBLE_DEVICES=1 \
python tool_add_control.py ../pokemon-sd/sd-lora-pro/logs/2024-06-27T15-34-02_opt/checkpoints/last.ckpt ./models/control_sd15_ini_opt_dora.ckpt

CUDA_VISIBLE_DEVICES=3 \
python train.py --sd_path ./models/control_sd15_ini_opt_dora.ckpt \
    --dataset SEN12_URBAN \
    --save_top_k 1 \
    --resume logs/2024-06-28T14-27-56_control_sd15_ini_SEN12_URBAN/testtube/version_0/checkpoints/epoch=319-step=199999.ckpt

#######
CUDA_VISIBLE_DEVICES=1 \
python tool_add_control.py "/data1/jbwei/crli/pokemon-sd/sd-lora/logs/2024-06-20T18-48-01_opt/checkpoints/last.ckpt" \
 ./models/control_sd15_ini_log.ckpt

CUDA_VISIBLE_DEVICES=1 \
python train.py --sd_path ./models/control_sd15_ini_log.ckpt \
    --dataset /home/jbwei/Pke/data/synthesis \
    --save_top_k -1 \
    --logdir /data1/jbwei/crli/ControlNet-v1-1-nightly/logs \
    --resume /data1/jbwei/crli/ControlNet-v1-1-nightly/logs/2024-07-08T11-03-27_control_sd15_ini_/home/jbwei/Pke/data/synthesis/testtube/version_0/checkpoints/epoch=474-step=349999.ckpt

########################### 0715 ###############################
CUDA_VISIBLE_DEVICES=2 \
python tool_add_control.py \
    /data1/jbwei/crli/pokemon-sd/sd-lora/logs/2024-05-28T17-40-12_opt-agri/checkpoints/last.ckpt \
    /data1/jbwei/crli/ControlNet-v1-1-nightly/models/control_sd15_ini_SEN12_AGRI_0715.ckpt


CUDA_VISIBLE_DEVICES=2 \
python train.py --sd_path /data1/jbwei/crli/ControlNet-v1-1-nightly/models/control_sd15_ini_SEN12_AGRI_0715.ckpt \
    --dataset SEN12_AGRI \
    --save_top_k -1 \
    --resume